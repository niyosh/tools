#!/usr/bin/env bash
# ==========================================================================
# config.sh  -  Central configuration. EDIT THIS before running anything.
# ==========================================================================

# --- Scope -----------------------------------------------------------------
# One IP, range, or CIDR per line. Comments (#) and blanks ignored.
SCOPE_FILE="${SCOPE_FILE:-scope.txt}"

# Where all output lands (timestamped run dir is created underneath).
OUTPUT_BASE="${OUTPUT_BASE:-./loot}"

# --- Performance -----------------------------------------------------------
THREADS="${THREADS:-20}"        # parallel per-host tasks
MIN_RATE="${MIN_RATE:-2000}"    # nmap packet rate (lower if unstable links)
NMAP_TIMING="${NMAP_TIMING:-4}" # -T value (4 = aggressive, 3 = polite)

# --- Active Directory credentials (OPTIONAL) -------------------------------
# Leave blank to skip all authenticated modules. Fill in once you have a foothold.
DOMAIN="${DOMAIN:-}"            # e.g. CORP.LOCAL
DC_IP="${DC_IP:-}"             # e.g. 10.10.10.10
USERNAME="${USERNAME:-}"
PASSWORD="${PASSWORD:-}"
NTHASH="${NTHASH:-}"           # NTLM hash for pass-the-hash (instead of PASSWORD)

# --- Password spray (DANGEROUS — read the warning in 06) -------------------
# Spray ONE password per run, then WAIT a full lockout window before the next.
SPRAY_PASSWORDS=("Welcome1" "Password1" "${DOMAIN%%.*}@2025")
LOCKOUT_OBSERVATION_MIN=35     # minutes between spray rounds (set above policy)

# --- Wordlists -------------------------------------------------------------
WEB_WORDLIST="${WEB_WORDLIST:-/usr/share/wordlists/dirb/common.txt}"
USER_WORDLIST="${USER_WORDLIST:-/usr/share/seclists/Usernames/xato-net-10-million-usernames-dup.txt}"

# --- Behaviour flags -------------------------------------------------------
SKIP_UDP="${SKIP_UDP:-false}"           # UDP scans are slow; set true to skip
SCREENSHOTS="${SCREENSHOTS:-true}"      # web screenshots via gowitness
SAFE_MODE="${SAFE_MODE:-true}"          # true = no auth attacks unless creds set
