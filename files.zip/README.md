# Internal Recon + AD Automation Kit

A modular Bash framework for **authorised** internal network penetration tests.
Built for Kali. Chains discovery → port/service scan → SMB/AD enum → web → DB →
AD attacks → vuln detection, organising all output into a timestamped run dir.

> **Use only against systems you are explicitly authorised to test.** The
> orchestrator forces a scope file and an authorisation confirmation. Password
> spraying and any exploitation are opt-in and gated. Keep your Rules of
> Engagement and lockout policy in front of you.

## Layout
```
pentest-kit/
├── config.sh            # EDIT: scope, creds, threads, wordlists, flags
├── run.sh               # orchestrator (start here)
├── lib/common.sh        # logging + helpers (sourced by all)
├── 00-setup.sh          # verify/install tooling
├── 01-discovery.sh      # live-host discovery (ARP + ICMP/TCP/UDP probes)
├── 02-portscan.sh       # full TCP + top UDP, -sCV, role classification
├── 03-enum-smb-ad.sh    # SMB/NetBIOS/LDAP, shares, users, RID brute, e4l-ng
├── 04-enum-web.sh       # httpx, whatweb, gowitness, nuclei, feroxbuster
├── 05-enum-db.sh        # MSSQL/MySQL/PG/Oracle/Mongo/Redis enum
├── 06-ad-attacks.sh     # AS-REP/Kerberoast, BloodHound, (opt-in) spray
└── 07-vuln-scan.sh      # MS17-010, Zerologon, PrintNightmare, TLS, SNMP
```

## Quick start
```bash
# 1. Define scope — one IP / range / CIDR per line
cat > scope.txt <<'EOF'
10.10.10.0/24
192.168.50.10-50
EOF

# 2. Check tooling
chmod +x *.sh lib/*.sh
./00-setup.sh

# 3. Edit config.sh (threads, wordlists; add domain creds once you have a foothold)

# 4. Run the full unauthenticated chain
./run.sh

# Selected phases only
./run.sh 01 02 04

# After you have valid domain creds, set them in config.sh and add attacks:
DOMAIN=CORP.LOCAL DC_IP=10.10.10.10 USERNAME=jdoe PASSWORD='Summer2025!' ./run.sh 03 06

# Opt-in password spray (read the warnings in 06 first):
./run.sh --spray
```

## Asset-to-module map for your environment
| Asset in scope        | Primary modules            | What you get |
|-----------------------|----------------------------|--------------|
| Domain Controllers    | 03, 06, 07                 | LDAP dump, roastable accounts, Zerologon/PetitPotam checks, BloodHound |
| File servers          | 03                         | Share enum, spider for sensitive files |
| Web / app servers     | 04                         | Tech fingerprint, nuclei, dirbusting, screenshots |
| Database servers      | 05                         | Version/empty-password/default-cred checks |
| Terminal / RDP / WinRM| 02 (classified), 06        | Exposed mgmt surfaces; lateral-movement targets once creds found |
| Hyper-V host          | 02, 03, 07                 | SMB/WinRM surface, vuln checks |
| DHCP server           | 02, 07                     | Service exposure |
| IP switch / endpoints | 01, 02, 07                 | SNMP default communities, mgmt interfaces |

## Output & follow-up
Everything lands in `loot/run-<timestamp>/`. The orchestrator prints a
"quick wins" list at the end. Crack any captured hashes offline:
```bash
hashcat -m 13100 kerberoast_hashes.txt rockyou.txt   # Kerberoast (TGS)
hashcat -m 18200 asrep_hashes.txt      rockyou.txt   # AS-REP
```
Import the BloodHound zip into the GUI to map attack paths to Domain Admin.

## Notes
- Modules degrade gracefully if a tool is missing — they skip, not crash.
- Tune `THREADS`, `MIN_RATE`, `NMAP_TIMING` down on fragile/segmented links.
- `SKIP_UDP=true` for big scopes where UDP scanning is too slow.
- `Responder`/`ntlmrelayx` (LLMNR/NBT-NS poisoning + relay) are intentionally
  **not** automated here — they're disruptive and need careful, attended use.
  Run them manually when your RoE permits.
